Task 7 folder contains design patterns
