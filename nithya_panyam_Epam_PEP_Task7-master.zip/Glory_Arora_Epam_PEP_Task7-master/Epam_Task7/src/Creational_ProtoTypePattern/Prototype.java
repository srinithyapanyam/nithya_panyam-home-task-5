package Creational_ProtoTypePattern;

public interface Prototype {

	public Prototype getClone();  

}