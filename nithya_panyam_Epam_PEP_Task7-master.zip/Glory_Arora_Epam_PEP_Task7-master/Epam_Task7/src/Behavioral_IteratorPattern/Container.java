package Behavioral_IteratorPattern;

public interface Container {
	public Iterator getIterator();  
}