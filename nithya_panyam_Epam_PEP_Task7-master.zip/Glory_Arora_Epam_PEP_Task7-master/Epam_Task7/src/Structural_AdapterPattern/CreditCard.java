package Structural_AdapterPattern;

public interface CreditCard 
{
	public void giveBankDetails();  
    public String getCreditCard();  
}