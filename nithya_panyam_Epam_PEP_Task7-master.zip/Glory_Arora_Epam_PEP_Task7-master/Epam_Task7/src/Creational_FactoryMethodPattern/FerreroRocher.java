package Creational_FactoryMethodPattern;

public class FerreroRocher extends Chocolate
{
	public void getPrice()
    {
         price=200;           
    }
}