package Creational_FactoryMethodPattern;

public class KitKat extends Chocolate
{
	public void getPrice()
    {
         price=100;           
    }
}