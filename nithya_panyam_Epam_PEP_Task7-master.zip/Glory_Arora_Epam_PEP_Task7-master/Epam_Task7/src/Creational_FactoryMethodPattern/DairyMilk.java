package Creational_FactoryMethodPattern;

public class DairyMilk extends Chocolate
{
	public void getPrice()
    {
         price=50;           
    }
}